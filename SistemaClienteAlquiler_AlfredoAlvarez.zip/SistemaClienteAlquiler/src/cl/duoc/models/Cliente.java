/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cl.duoc.models;

/**
 *
 * @author Cetecom
 */
public class Cliente {
    private int id_cliente;
    
    private String rut;
    private String nombre;
    private String num_contacto;
    private String direccion;
    private boolean cliente_alquiler;

    public Cliente() {
    }

    public Cliente(int id_cliente, String rut, String nombre, String num_contacto, String direccion, boolean cliente_alquiler) {
        this.id_cliente = id_cliente;
        this.rut = rut;
        this.nombre = nombre;
        this.num_contacto = num_contacto;
        this.direccion = direccion;
        this.cliente_alquiler = cliente_alquiler;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNum_contacto() {
        return num_contacto;
    }

    public void setNum_contacto(String num_contacto) {
        this.num_contacto = num_contacto;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public boolean isCliente_alquiler() {
        return cliente_alquiler;
    }

    public void setCliente_alquiler(boolean cliente_alquiler) {
        this.cliente_alquiler = cliente_alquiler;
    }

    
    
    
}
