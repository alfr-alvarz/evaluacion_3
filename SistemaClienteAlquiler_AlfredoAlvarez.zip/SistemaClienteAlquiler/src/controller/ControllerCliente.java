/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import cl.duoc.models.Cliente;
import java.sql.ResultSet;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Cetecom
 */
public class ControllerCliente {
    private static int idCliente = 1;

    
    private List<Cliente> clientes = new ArrayList<>();
    
    public boolean existenciaPrevio(Cliente parCliente){
        for(Cliente i: clientes){
            if (i.getRut().equalsIgnoreCase(parCliente.getRut())){
                return true; //retorna que si hay una existencia previa.
            }  
        }
        return false;
    }
    
    
    public void agregarCliente(Cliente parCliente){
        clientes.add(parCliente);
    }
    
    public static int getIdCliente() {
        return idCliente;
    }

    public static void setIdCliente(int idCliente) {
        ControllerCliente.idCliente = idCliente;
    }
    
    
}
